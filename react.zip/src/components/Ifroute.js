import React from 'react';
import Login from './Login';
import { BrowserRouter, Router, Route , Routes } from 'react-router-dom';
import Sidermenu from './menu_sider';
import Main from './Main';
import Notice from './Notice';
import NoticeAdd from './NoticeAdd';
import Noticedetail from './NoticeDetail';
import Barchart from './ChartList';
const Ifroute = (
    ) => {
    return (
       <div>
        <Sidermenu/>
        <Routes>
        <Route  path = {"/"}  element = {<Main/>}></Route>
        <Route  path = {"/notice"}  element = {<Notice/>}></Route>
        <Route  path = {"/Noticedetail"}  element = {<Noticedetail/>}></Route>
        <Route path=":keyword" element={<Noticedetail/>} />
        <Route  path = {"/Noticeadd"}  element = {<NoticeAdd/>}></Route>
        <Route  path = {"/chart"}  element = {<Barchart/>}></Route>
        </Routes>
     
        </div>
    );
};

export default Ifroute;